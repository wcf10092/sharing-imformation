module.exports = {
  // 继承推荐规范配置
  extends: [
    "stylelint-config-standard",
    "stylelint-config-recommended-scss",
    "stylelint-config-recommended-vue/scss",
    "stylelint-config-html/vue",
    "stylelint-config-recess-order",
  ],
  // 指定不同文件对应的解析器
  overrides: [
    {
      files: ["**/*.{vue,html}"],
      customSyntax: "postcss-html",
    },
    {
      files: ["**/*.{css,scss}"],
      customSyntax: "postcss-scss",
    },
  ],
  // 自定义规则
  rules: {
    "import-notation": "string", // 指定导入CSS文件的方式("string"|"url")
    "selector-class-pattern": null, // 选择器类名命名规则
    "custom-property-pattern": null, // 自定义属性命名规则
    "keyframes-name-pattern": null,
    "property-no-unknown": null, // 允许未知的属性
    "no-descending-specificity": null,
    // 允许 global 、export 伪类
    "selector-pseudo-class-no-unknown": [
      true,
      {
        ignorePseudoClasses: ["global", "export", "deep"],
      },
    ],
  },
};

// .stylelintrc.cjs 是 Stylelint 的配置文件，用于指定 CSS 或 SCSS 代码的规则和配置。
// .stylelintrc.cjs 文件采用 CommonJS 模块化语法，用于向 Stylelint 提供项目特定的配置。它可以包含以下内容：
// 1. `extends`：继承其他配置文件的规则。可以使用预设的规则集，也可以继承自其他项目或共享的规则集。
// 2. `plugins`：插件的配置。可以引入第三方插件并配置它们的规则。
// 3. `rules`：自定义的规则。可以启用、禁用或修改特定规则。
// 4. `ignoreFiles`：指定需要忽略的文件或文件夹。
// 在项目根目录下创建 .stylelintrc.cjs 文件，并根据项目需求配置相关选项。配置文件中的规则和选项将被 Stylelint 用于静态代码分析，以提供代码质量和风格的建议和警告。
// 需要注意的是，配置文件的具体内容和格式可能因项目而异。可以根据具体项目需求和团队规范进行配置，并结合 Stylelint 的文档和规则集来定义适合项目的代码规范。
// 另外，需要确保在项目中安装了 Stylelint 及相关的插件，以便使配置文件生效，并能够在代码编辑器或构建工具中进行相应的检查和格式化。