module.exports = {
  env: {
    browser: true,
    es2021: true,
    node: true,
  },
  parser: "vue-eslint-parser",
  //  https://eslint.vuejs.org/user-guide/#bundle-configurations
  extends: [
    "eslint:recommended",
    "plugin:vue/vue3-essential",
    "plugin:@typescript-eslint/recommended",
    "./.eslintrc-auto-import.json",
  ],
  parserOptions: {
    ecmaVersion: "latest",
    sourceType: "module",
    parser: "@typescript-eslint/parser",
  },
  plugins: ["vue", "@typescript-eslint"],
  rules: {
    "vue/multi-word-component-names": "off", // 关闭组件名必须多字： https://eslint.vuejs.org/rules/multi-word-component-names.html
    "@typescript-eslint/no-empty-function": "off", // 关闭空方法检查
    "@typescript-eslint/no-explicit-any": "off", // 关闭any类型的警告
    "vue/no-v-model-argument": "off",
    "@typescript-eslint/no-non-null-assertion": "off",
  },
  // https://eslint.org/docs/latest/use/configure/language-options#specifying-globals
  globals: {
    DialogOption: "readonly",
    OptionType: "readonly",
  },
};


// .eslintrc.cjs 是 ESLint 的配置文件，用于指定 JavaScript 代码的规则和配置。
// .eslintrc.cjs 文件采用 CommonJS 模块化语法，用于向 ESLint 提供项目特定的配置。它可以包含以下内容：
// 1. `env`：指定代码运行的环境。可以设置为浏览器、Node.js、ES6 等。
// 2. `extends`：继承其他配置文件的规则。可以使用预设的规则集，也可以继承自其他项目或共享的规则集。
// 3. `rules`：自定义的规则。可以启用、禁用或修改特定规则。
// 4. `plugins`：插件的配置。可以引入第三方插件并配置它们的规则。
// 5. `parserOptions`：解析器选项。可以指定解析器的版本、支持的 ECMAScript 版本等。
// 6. `globals`：全局变量的配置。用于定义全局变量，避免 ESLint 报错。
// 在项目根目录下创建 .eslintrc.cjs 文件，并根据项目需求配置相关项。配置文件中的规则和选项将被 ESLint 用于静态代码分析，以提供代码质量和风格的建议和警告。
// 需要注意的是，配置文件的具体内容和格式可能因项目而异。可以根据具体项目需求和团队规范进行配置，并结合 ESLint 的文档和规则集来定义适合项目的代码规范。