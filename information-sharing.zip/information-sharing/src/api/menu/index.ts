import { AxiosPromise } from 'axios';
import { MenuQuery, MenuVO, MenuForm } from './types';
import service from '@/utils/request'
const { systemService } = service
/**
 * 获取路由列表
 */
export function listRoutes() {
  return systemService({
    url: '/system/menus/routes',
    method: 'get'
  });
}

/**
 * 获取菜单树形列表
 *
 * @param queryParams
 */
export function listMenus(queryParams: MenuQuery): AxiosPromise<MenuVO[]> {
  return systemService({
    url: '/system/menus',
    method: 'get',
    params: queryParams
  });
}

/**
 * 获取菜单下拉树形列表
 */
export function listMenuOptions(): AxiosPromise<OptionType[]> {
  return systemService({
    url: '/system/menus/options',
    method: 'get'
  });
}

/**
 * 获取菜单表单数据
 *
 * @param id
 */
export function getMenuForm(id: number): AxiosPromise<MenuForm> {
  return systemService({
    url: '/system/menus/' + id + '/form',
    method: 'get'
  });
}

/**
 * 添加菜单
 *
 * @param data
 */
export function addMenu(data: MenuForm) {
  return systemService({
    url: '/system/menus',
    method: 'post',
    data: data
  });
}

/**
 * 修改菜单
 *
 * @param id
 * @param data
 */
export function updateMenu(id: string, data: MenuForm) {
  return systemService({
    url: '/system/menus/' + id,
    method: 'put',
    data: data
  });
}

/**
 * 删除菜单
 *
 * @param id 菜单ID
 */
export function deleteMenu(id: number) {
  return systemService({
    url: '/system/menus/' + id,
    method: 'delete'
  });
}
