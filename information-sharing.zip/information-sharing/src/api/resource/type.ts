//管理员审核 || 修改 ||添加

export interface Article {
  id: number;
  authorUsername?: string;
  title: string;
  describe: string;
  tags?: string;
  cover?: string;
  type: number;
  path: string;
  cost?: number;
  visible: number;
  resourceName: string;
  status?: number;
  publishTime?: string;
  managerUsername?: string;
  downloadRecord?: number;
  createTime?: string;
}

/**
 * 获取管理员列表
 */
export interface getListInfo {
  param?: {
    pageNum?: number;
    pageSize?: number;
  };
  status?: number;
  typeId?: number;
}


/**
 * 删除
 */

export interface getDelete {
  id: number;
}

export interface AdminQuery{
  keywords?: string;
  status?: number;
  deptId?: number;
}
