import { getListInfo, Article, getDelete } from "./type";
import service from "@/utils/request";
import { AxiosPromise } from "axios";

const { resourceService } = service;
/**
 * 管理员获取列表
 *
 */
export function getResource(data: getListInfo): AxiosPromise<any> {
  return resourceService({
    url: "/resource/instrument/managerGetList",
    method: "get",
    params: data,
  });
}

/**
 * guan修改
 */
export function updatainfo(data: Article): AxiosPromise<any> {
  return resourceService({
    url: "/resource/instrument/updateByManager",
    method: "put",
    data: data,
  });
}


/**
 * 管理员删除
 */

// export function deleteAdmin(id: number): AxiosPromise<any> {
//   return resourceService({
//     url: "/resource/instrument/delete/" + id,
//     method: "delete",
//   });
// }

export function deleteAdmin(ids: number[]): AxiosPromise<any> {
  return resourceService({
    url: "/resource/instrument/delete/" + ids.join(","),
    method: "delete",
  });
}


/**
 * 管理员获取详情
 */
export function getDetail(id: number): AxiosPromise<any> {
  return resourceService({
    url: "/resource/instrument/managerGetById/" + id,
    method: "get",
  });
}

/**
 * 管理员审核
 */

export function examine(data: Article): AxiosPromise<any> {
  return resourceService({
    url: "/resource/instrument/audit",
    method: "put",
    data: data,
  });
}
