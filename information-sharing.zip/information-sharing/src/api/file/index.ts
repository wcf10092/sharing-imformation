import { AxiosPromise } from 'axios';
import { FileInfo } from './types';
import service from '@/utils/request'
const { systemService } = service

/**
 * 上传文件
 *
 * @param file
 */
export function uploadFileApi(file: File): AxiosPromise<FileInfo> {
  const formData = new FormData();
  formData.append('file', file);
  return systemService({
    url: '/system/files',
    method: 'post',
    data: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
}

/**
 * 删除文件
 *
 * @param filePath 文件完整路径
 */
export function deleteFileApi(filePath?: string) {
  return systemService({
    url: '/system/files',
    method: 'delete',
    params: { filePath: filePath }
  });
}
