import { AxiosPromise } from 'axios';
import { DeptForm, DeptQuery, DeptVO } from './types';
import service from '@/utils/request'
const { systemService } = service

/**
 * 部门树形表格
 *
 * @param queryParams
 */
export function listDepts(queryParams?: DeptQuery): AxiosPromise<DeptVO[]> {
  return systemService({
    url: '/system/dept',
    method: 'get',
    params: queryParams
  });
}

/**
 * 部门下拉列表
 */
export function listDeptOptions(): AxiosPromise<[]> {
  return systemService({
    url: '/system/dept/options',
    method: 'get'
  });
}

/**
 * 获取部门详情
 *
 * @param id
 */
export function getDeptForm(id: number): AxiosPromise<DeptForm> {
  return systemService({
    url: '/system/dept/' + id + '/form',
    method: 'get'
  });
}

/**
 * 新增部门
 *
 * @param data
 */
export function addDept(data: DeptForm) {
  return systemService({
    url: '/system/dept',
    method: 'post',
    data: data
  });
}

/**
 *  修改部门
 *
 * @param id
 * @param data
 */
export function updateDept(id: number, data: DeptForm) {
  return systemService({
    url: '/system/dept/' + id,
    method: 'put',
    data: data
  });
}

/**
 * 删除部门
 *
 * @param ids
 */
export function deleteDept(ids: string) {
  return systemService({
    url: '/api/v1/dept/' + ids,
    method: 'delete'
  });
}
