import { AxiosPromise } from 'axios';
import { CaptchaResult, LoginData, LoginResult } from './types';
import service from '@/utils/request'
const { systemService } = service
/**
/**
 * 登录API
 *
 * @param data {LoginData}
 * @returns
 */
export function loginApi(data: LoginData): AxiosPromise<LoginResult> {
  return systemService({
    url: '/system/auth/login',
    method: 'post',
    params: data
  });
}

/**
 * 注销API
 */
export function logoutApi() {
  return systemService({
    url: '/sharing/auth/logout',
    method: 'delete'
  });
}



/**
 * 获取验证码
 */
// export function getCaptchaApi(): AxiosPromise<CaptchaResult> {
//   return request({
//     url: '/sharing/auth/captcha',
//     method: 'get'
//   });
// }
