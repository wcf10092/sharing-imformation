<template>
  <div style="padding: 30px">
    <el-alert :closable="false" title="菜单三级-2" type="warning" />
  </div>
</template>
