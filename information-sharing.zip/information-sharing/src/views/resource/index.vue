<template>
  <div>
    <el-card>
      <div class="search">
        <el-form ref="queryFormRef" :model="queryParams" :inline="true">
          <!-- <el-form-item label="关键字" prop="keywords">
            <el-input
              placeholder="标题/状态"
              clearable
              style="width: 200px"
              @keyup.enter=""
            />
          </el-form-item> -->

          <el-form-item label="状态" prop="status">
            <el-select
              v-model="queryParams.status"
              placeholder="全部"
              clearable
              style="width: 200px"
            >
              <el-option label="待审核" value="1" />
              <el-option label="审核通过" value="2" />
            </el-select>
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="handleData"><i-ep-search />搜索</el-button>
            <el-button @click="resetQuery">
              <i-ep-refresh />
              重置</el-button
            >
          </el-form-item>
        </el-form>
      </div>

      <div>
        <el-button
          type="danger"
          :disabled="ids.length === 0"
          @click="deleteClick()"
          v-hasPerm="['sys:user:delete']"
          ><i-ep-delete />删除</el-button
        >
      </div>
    </el-card>

    <el-card>
      <div>
        <el-form>
          <el-form-item>
            <el-table
              :data="dataList"
              style="width: 100%"
              @selection-change="handleSelectionChange"
            >
              <el-table-column type="selection" width="50" align="center" />
              <el-table-column fixed prop="id" label="id" width="150" />
              <el-table-column prop="title" label="标题" width="120" />
              <el-table-column prop="describe" label="描述" width="120" />

              <el-table-column prop="status" label="状态" width="120">
                <template #default="scope">
                  <span v-if="scope.row.status === 1">待审核</span>
                  <span v-else-if="scope.row.status === 2">审核通过</span>
                  <span v-else-if="scope.row.status === 3">内容违规</span>
                </template>
              </el-table-column>

              <el-table-column prop="authorUsername" label="发布人" width="120" />
              <el-table-column prop="downloadRecord" label="下载次数" width="120" />
              <el-table-column prop="createTime" label="发布时间" width="120" />

              <el-table-column fixed="right" label="操作" width="240">
                <template #default="scope">
                  <el-button
                    link
                    type="primary"
                    size="small"
                    v-if="scope.row.status === 1"
                    @click="handleClick(scope.row.id)"
                  >
                    审核
                  </el-button>
                  <el-button
                    link
                    type="primary"
                    size="small"
                    @click="detailsClick(scope.row.id)"
                    >详情</el-button
                  >
                  <el-button
                    link
                    type="primary"
                    size="small"
                    @click="openDialog(scope.row.id)"
                    >编辑</el-button
                  >
                  <el-button
                    link
                    type="primary"
                    size="small"
                    @click="deleteClick(scope.row.id)"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <el-dialog v-model="dialog.visible" title="详细信息">
      <el-table :data="detailList" style="width: 100%">
        <el-table-column type="expand">
          <template #default="props">
            <div m="7">
              <p m="t-0 b-2">资源标签: {{ props.row.tags }}</p>
              <p m="t-0 b-2">资源的封面图片路径: {{ props.row.cover }}</p>
              <p m="t-0 b-2">资源类型: {{ props.row.type }}</p>
              <p m="t-0 b-2">资源费用: {{ props.row.cost }}</p>
              <p m="t-0 b-2">资源的路径或链接: {{ props.row.path }}</p>
              <p m="t-0 b-2">资源可见性: {{ props.row.visible }}</p>
              <p m="t-0 b-2">资源管理者用户名: {{ props.row.managerUsername }}</p>
              <p m="t-0 b-2">资源创建时间: {{ props.row.createTime }}</p>
              <h3>初始界面显示信息</h3>
              <el-table :data="detailList">
                <el-table-column label="id" prop="id" />
                <el-table-column label="资源标题" prop="title" />
                <el-table-column label="描述" prop="describe" />
                <el-table-column label="状态" prop="status" />
                <el-table-column label="发布人" prop="authorUsername" />
                <el-table-column label="下载次数" prop="downloadRecord" />
              </el-table>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="发布时间" prop="createTime" />
        <el-table-column label="发布人" prop="authorUsername" />
      </el-table>
    </el-dialog>

    <el-dialog v-model="editDialog.visible" title="编辑">
      <el-radio-group v-model="labelPosition" label="label position">
        <el-radio-button label="left">Left</el-radio-button>
        <el-radio-button label="right">Right</el-radio-button>
        <el-radio-button label="top">Top</el-radio-button>
      </el-radio-group>
      <div style="margin: 20px" />
      <el-form
        ref="detailFormRef"
        :rules="rules"
        :model="formData"
        :label-position="labelPosition as 'right' "
        label-width="100px"
        style="max-width: 460px"
      >
        <el-form-item label="id">
          <el-input-number v-model="formData.id" />
        </el-form-item>

        <el-form-item label="用户">
          <el-input v-model="formData.authorUsername" />
        </el-form-item>

        <el-form-item label="标题">
          <el-input v-model="formData.title" />
        </el-form-item>

        <el-form-item label="描述">
          <el-input v-model="formData.describe" />
        </el-form-item>

        <el-form-item label="标签">
          <el-input v-model="formData.tags" />
        </el-form-item>
        <el-form-item label="图片路径">
          <el-input v-model="formData.cover" />
        </el-form-item>
        <el-form-item label="资源类型">
          <el-input-number v-model="formData.type" />
        </el-form-item>
        <el-form-item label="资源路径">
          <el-input v-model="formData.path" />
        </el-form-item>
        <el-form-item label="资源费用">
          <el-input-number v-model="formData.cost" />
        </el-form-item>
        <el-form-item label="资源的可见性">
          <el-input-number v-model="formData.visible" />
        </el-form-item>
        <el-form-item label="资源的名称">
          <el-input v-model="formData.resourceName" />
        </el-form-item>
        <el-form-item label="资源的状态 ">
          <el-input-number v-model="formData.status" />
        </el-form-item>
        <el-form-item label="资源的发布时间">
          <el-input v-model="formData.publishTime" />
        </el-form-item>
        <el-form-item label="管理者用户名">
          <el-input v-model="formData.managerUsername" />
        </el-form-item>
        <el-form-item label="资源下载记录">
          <el-input-number v-model="formData.downloadRecord" />
        </el-form-item>
        <el-form-item label="资源创建时间">
          <el-input v-model="formData.createTime" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="handleSubmit">确 定</el-button>
          <el-button @click="closeDialog">取 消</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 审核 -->
    <el-dialog v-model="dialogExamineVisible.visible" title="审核信息">
      <el-form :model="formData">
        <el-form-item label="id" :label-width="formLabelWidth">
          <el-input v-model="formData.id" autocomplete="off" />
        </el-form-item>
        <el-form-item label="状态" :label-width="formLabelWidth">
          <el-select v-model="formData.status" placeholder="请选择状态">
            <el-option label="通过" value="2" />
            <el-option label="不通过" value="3" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogExamineVisible.visible = false">取消</el-button>
          <el-button type="primary" @click="axamineSubmit"> 确定 </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts" setup>
import { getResource, deleteAdmin, updatainfo, getDetail, examine } from "@/api/resource";
import { Article, getListInfo, AdminQuery } from "@/api/resource/type";
import { dialogEmits } from "element-plus";
import { Loading } from "element-plus/es/components/loading/src/service";
import { reactive, ref } from "vue";

const dataList = ref<Article[]>();
const detailList = ref<Article[]>();
const loading = ref(false);
const dialogTableVisible = ref(false);

const ids = ref([]);

const formLabelWidth = "140px";

const queryParams = reactive<getListInfo>({});

//审核弹框
const dialogExamineVisible = reactive<DialogOption>({
  visible: false,
});

const dialog = reactive<DialogOption>({
  visible: false,
});

//编辑弹框
const editDialog = reactive<DialogOption>({
  visible: false,
});

/**
 * 行checkbox change事件
 */
function handleSelectionChange(selection: any) {
  ids.value = selection.map((item: any) => item.id);
}

let formData = reactive<Article>({
  id: 0,
  authorUsername: "",
  title: "",
  describe: "",
  tags: "",
  cover: "",
  type: 0,
  path: "",
  cost: 0,
  visible: 0,
  resourceName: "",
  status: 0,
  publishTime: "",
  managerUsername: "",
  downloadRecord: 0,
  createTime: "",
});

const queryFormRef = ref(ElForm); // 查询表单

const labelPosition = ref("right");

const detailFormRef = ref(ElForm); // 用户表单

const rules = reactive({
  id: [{ required: true, message: "id不能为空", trigger: "blur" }],
  title: [{ required: true, message: "标题不能为空", trigger: "blur" }],
  describe: [{ required: true, message: "用户角色不能为空", trigger: "blur" }],
  type: [{ required: true, message: "资源的类型不能为空", trigger: "blur" }],
  path: [{ required: true, message: "路径不能为空", trigger: "blur" }],
  visible: [{ required: true, message: "资源的可见性不能为空", trigger: "blur" }],
  resourceName: [{ required: true, message: "资源的名称不能为空", trigger: "blur" }],
});

//删除
async function deleteClick(id?: number) {
  const adminIds = [id || ids.value] as number[];
  if (!adminIds) {
    ElMessage.warning("请勾选删除项");
    return;
  }
  await ElMessageBox.confirm("确认删除用户?", "警告", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(function () {
    deleteAdmin(adminIds).then(() => {
      ElMessage.success("删除成功");
      resetQuery();
    });
  });
}

//审核弹框
async function handleClick(id: number) {
  dialogExamineVisible.visible = true;
  await getDetail(id).then(({ data }) => {
    formData = Object.assign({}, data.resource);
  });
}

async function axamineSubmit() {
  loading.value = true;

  await examine(formData)
    .then(() => {
      ElMessage.success("审核成功");
      closeDialog();
      resetQuery();
    })
    .finally(() => (loading.value = false));
}

//打开弹窗
async function openDialog(id: number) {
  editDialog.visible = true;
  editDialog.title = "修改数据";
  await getDetail(id).then(({ data }) => {
    formData = Object.assign({}, data.resource);
  });
}

//修改数据提交
async function handleSubmit() {
  await detailFormRef.value.validate((valid: any) => {
    if (valid) {
      loading.value = true;
      updatainfo(formData)
        .then(() => {
          ElMessage.success("修改用户成功");
          closeDialog();
          resetQuery();
        })
        .finally(() => (loading.value = false));
    }
  });
}
/**
 *
 * @param id 重置查询
 */
function resetQuery() {
  queryFormRef.value.resetFields();
  handleData();
}

//详情
async function detailsClick(id: number) {
  dialog.visible = true;
  await getDetail(id).then(({ data }) => {
    detailList.value = [data.resource];
    console.log(detailList);
  });
}

function closeDialog() {
  editDialog.visible = false;
  dialogExamineVisible.visible = false;
  handleData();
}

//获取数据
async function handleData() {
  loading.value = true;
  await getResource(queryParams)
    .then(({ data }) => {
      dataList.value = data.resources;
      // console.log(dataList);
    })
    .catch((error) => {
      console.error("Error:", error);
    })
    .finally(() => {
      loading.value = false;
    });
}

onMounted(() => {
  handleData();
});
</script>
