import vue from "@vitejs/plugin-vue";

import { UserConfig, ConfigEnv, loadEnv, defineConfig } from "vite";

import AutoImport from "unplugin-auto-import/vite";
import Components from "unplugin-vue-components/vite";
import { ElementPlusResolver } from "unplugin-vue-components/resolvers";

import Icons from "unplugin-icons/vite";
import IconsResolver from "unplugin-icons/resolver";

import { createSvgIconsPlugin } from "vite-plugin-svg-icons";

import UnoCSS from "unocss/vite";

import path from "path";
const pathSrc = path.resolve(__dirname, "src");

export default defineConfig(({ mode }: ConfigEnv): UserConfig => {
  const env = loadEnv(mode, process.cwd());
  return {
    resolve: {
      alias: {
        "@": pathSrc,
      },
    },
    css: {
      // CSS 预处理器
      preprocessorOptions: {
        //define global scss variable
        scss: {
          javascriptEnabled: true,
          additionalData: `
            @use "@/styles/variables.scss" as *;
          `,
        },
      },
    },
    server: {
      host: "0.0.0.0",
      port: Number(env.VITE_APP_PORT),
      open: true, // 运行是否自动打开浏览器
      proxy: {
        [env.VITE_APP_SYSTEM_API]: {
          //获取数据的服务器地址设置
          target: env.VITE_SYSTEM_SERVE,
          //需要代理跨域
          changeOrigin: true,
          //路径重写
          rewrite: (path) =>
            path.replace(new RegExp("^" + env.VITE_APP_SYSTEM_API), ""),
        },
        [env.VITE_APP_RESOURCE_API]: {
          // 本地接口API地址
          target: env.VITE_RESOURCE_SERVE,
          changeOrigin: true,
          rewrite: (path) =>
            path.replace(new RegExp("^" + env.VITE_APP_RESOURCE_API), ""),
        },
      },
    },
    plugins: [
      vue(),
      UnoCSS({
        /* options */
      }),
      AutoImport({
        // 自动导入 Vue 相关函数，如：ref, reactive, toRef 等
        imports: ["vue", "@vueuse/core"],
        eslintrc: {
          enabled: false, //  Default `false`
          filepath: "./.eslintrc-auto-import.json", // Default `./.eslintrc-auto-import.json`
          globalsPropValue: true, // Default `true`, (true | false | 'readonly' | 'readable' | 'writable' | 'writeable')
        },
        resolvers: [
          // 自动导入 Element Plus 相关函数，如：ElMessage, ElMessageBox... (带样式)
          ElementPlusResolver(),
          // 自动导入图标组件
          IconsResolver({}),
        ],
        vueTemplate: true, // 是否在 vue 模板中自动导入
        dts: path.resolve(pathSrc, "types", "auto-imports.d.ts"), //  自动导入组件类型声明文件位置，默认根目录; false 关闭自动生成
      }),

      Components({
        resolvers: [
          // 自动注册图标组件
          IconsResolver({
            enabledCollections: ["ep"], //@iconify-json/ep 是 Element Plus 的图标库
          }),
          // 自动导入 Element Plus 组件
          ElementPlusResolver(),
        ],
        dts: path.resolve(pathSrc, "types", "components.d.ts"), //  自动导入组件类型声明文件位置，默认根目录; false 关闭自动生成
      }),

      Icons({
        // 自动安装图标库
        autoInstall: true,
      }),

      createSvgIconsPlugin({
        // 指定需要缓存的图标文件夹
        iconDirs: [path.resolve(pathSrc, "assets/icons")],
        // 指定symbolId格式
        symbolId: "icon-[dir]-[name]",
      }),
    ],
    optimizeDeps: {
      include: [
        "vue",
        "vue-router",
        "pinia",
        "axios",
        "element-plus/es/components/form/style/css",
        "element-plus/es/components/form-item/style/css",
        "element-plus/es/components/button/style/css",
        "element-plus/es/components/input/style/css",
        "element-plus/es/components/input-number/style/css",
        "element-plus/es/components/switch/style/css",
        "element-plus/es/components/upload/style/css",
        "element-plus/es/components/menu/style/css",
        "element-plus/es/components/col/style/css",
        "element-plus/es/components/icon/style/css",
        "element-plus/es/components/row/style/css",
        "element-plus/es/components/tag/style/css",
        "element-plus/es/components/dialog/style/css",
        "element-plus/es/components/loading/style/css",
        "element-plus/es/components/radio/style/css",
        "element-plus/es/components/radio-group/style/css",
        "element-plus/es/components/popover/style/css",
        "element-plus/es/components/scrollbar/style/css",
        "element-plus/es/components/tooltip/style/css",
        "element-plus/es/components/dropdown/style/css",
        "element-plus/es/components/dropdown-menu/style/css",
        "element-plus/es/components/dropdown-item/style/css",
        "element-plus/es/components/sub-menu/style/css",
        "element-plus/es/components/menu-item/style/css",
        "element-plus/es/components/divider/style/css",
        "element-plus/es/components/card/style/css",
        "element-plus/es/components/link/style/css",
        "element-plus/es/components/breadcrumb/style/css",
        "element-plus/es/components/breadcrumb-item/style/css",
        "element-plus/es/components/table/style/css",
        "element-plus/es/components/tree-select/style/css",
        "element-plus/es/components/table-column/style/css",
        "element-plus/es/components/select/style/css",
        "element-plus/es/components/option/style/css",
        "element-plus/es/components/pagination/style/css",
        "element-plus/es/components/tree/style/css",
        "element-plus/es/components/alert/style/css",
        "@vueuse/core",

        "path-to-regexp",
        "echarts",
        "@wangeditor/editor",
        "@wangeditor/editor-for-vue",
        "vue-i18n",
      ],
    },
  };
});

// 这段代码是一个 Vue.js 项目的配置文件，它的作用是配置项目的构建、开发和运行环境。具体来说：
// 1. 使用`defineConfig`函数定义一个配置对象，通过`loadEnv`函数加载环境变量。
// 2. 在`resolve`中配置别名，将`@`指向`pathSrc`变量的值。
// 3. 在`css`中配置CSS预处理器，这里使用的是SCSS，并定义了全局的SCSS变量。
// 4. 在`server`中配置开发服务器的相关设置，包括主机和端口号，以及反向代理解决跨域问题。
// 5. 在`plugins`中配置一系列插件，包括vue插件、UnoCSS插件、AutoImport插件等。这些插件用于自动导入、注册组件、图标等，以及对SVG图标进行缓存处理。
// 6. 在`optimizeDeps`中配置需要进行优化的依赖项，包括Vue、Vue Router、Pinia、Axios等。
// 总的来说，这段代码的作用是配置项目的开发环境，包括解决跨域问题、自动导入组件和图标、优化依赖项等。

// vite.config.ts 是 Vite 构建工具的配置文件，它使用 TypeScript 编写。
// vite.config.ts 文件用于配置 Vite 项目的构建和开发环境。它可以包含以下内容：
// 1. `root`：指定项目根目录的路径。
// 2. `base`：指定项目的基础路径，用于构建时的静态资源路径。
// 3. `build`：用于配置构建相关的选项，例如输出目录、是否进行压缩等。
// 4. `resolve`：用于配置模块解析的选项，例如别名、扩展名等。
// 5. `plugins`：用于配置 Vite 插件的选项，例如引入第三方插件、配置插件选项等。
// 6. `server`：用于配置开发服务器的选项，例如主机、端口、代理等。
// 7. `optimizeDeps`：用于配置优化依赖的选项，例如指定哪些依赖需要进行预构建等。
// 在项目根目录下创建 vite.config.ts 文件，并根据项目需求配置相关选项。配置文件中的选项将被 Vite 构建工具用于项目的构建和开发环境。
// 需要注意的是，配置文件的具体内容和格式可能因项目而异。可以根据具体项目需求和团队规范进行配置，并结合 Vite 的文档来定义适合项目的构建和开发配置。
// 另外，需要确保在项目中安装了 Vite 及相关的插件，以便使配置文件生效，并能够正常构建和运行项目。
